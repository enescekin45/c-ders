﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ÖDEV
{
    class Program
    {
        static void Main(string[] args)
        {
            //İLK DERS 
            string ad, soyad;
             Console.WriteLine("adnınızı giriniz");
             ad = Console.ReadLine();
             Console.WriteLine("soyadınızı giriniz");
             soyad = Console.ReadLine();
             Console.WriteLine("ad=" + ad+"" + "soayd" + ""+soyad);
             Console.Read();


            Console.WriteLine("Kenar değeri giriniz:");
             int kenar=Convert.ToInt32(Console.ReadLine());
             int cevre = kenar * 4;
             Console.WriteLine("cevere sonuç" + cevre);
             Console.Read();

             int carpim = 1;
             for (int i = 1; i <10; i++)
             {
                 for (int y= 1; y <10; y++)
                 {
                     carpim = y + i;
                 }
                 Console.WriteLine(carpim);
                 Console.Read();
             }

           
            decimal bakiye = 100m;
            Console.WriteLine("Hoş Geldiniz");
            Console.WriteLine("Mecut  bakiye" + bakiye + "tl");
            Console.WriteLine("Çekmek istediğimiz tutar");
            decimal cekilecekTutar = Convert.ToDecimal(Console.ReadLine());
            if (cekilecekTutar > bakiye)
            {
                Console.WriteLine("Yetersiz Bakiye");
            }
            else
            {
                Console.WriteLine("işlem gercekleşti");
                Console.WriteLine("Çekilentutar" + cekilecekTutar + "tl");
                Console.WriteLine("kanlanbakiye" + bakiye + "tl");
            }
            Console.Read();




        }
    }
}
